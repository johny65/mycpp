#include <string>
#include <vector>

namespace pdf_extract {
    using std::string;
    using std::vector;

    vector<string*>* outline(string filename);
}
